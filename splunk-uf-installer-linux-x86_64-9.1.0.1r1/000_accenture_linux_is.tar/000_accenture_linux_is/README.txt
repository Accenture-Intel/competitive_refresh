########## Accenture Linux IS App ############

Dependencies: Splunk Add-on for Unix and Linux (https://splunkbase.splunk.com/app/833/)

Latest Version: 2.1.6

Changelog
2.0.0	- Start tracking app version as a whole in addition to individual script versions
	- add_meta.sh version 1.7
	- aurules_update.sh version 1.1
	- get_audit.sh version 2.1
	- get_env_details.sh version 3.5
	- audit2splunk.py version 3.0

2.1.0	- added get_audit_ng.sh ver. 1.1 to collect audit logs without a need of python

2.1.1	- Some perf improvements in get_audit_ng.sh ver. 1.2

2.1.2	- get_env_details.sh version 3.6 - minor fix to openssl call

2.1.3	- get_env_details.sh version 3.6 - removed Python, added isapps_version and UF/HF

2.1.4	- Updated get_audit_ng.sh to 1.4 - ignore all logs older than 1 week in history
	- Updated get_env_details.sh to 3.8 - get app version and few other changes

2.1.5	- Updated get_env_details.sh to 3.9 - minor fix to journald detection

2.1.6	- Updated get_env_details.sh to 3.10 - get Splunk package maintainer (ACNIS supported only so far)
	- Updated aurules_update.sh to 1.2 - rules files moved to static folder
